# dpdk-framework


## dpdk-rx: DPDK Receiver Program

```
./dpdk-rx [EAL options] -- --options
    -p, --port                  port to receive packets (default 0)
    -i, --interval              seconds between periodic reports, only appliable when call_main is disabled (default 1)
    -l, --latency               test latency, it will store an array of latency stats (default array size is 0)
    -r, --packet-rate           maximum number of packets to receive per second (no rate limiting by default)
    -t, --test-pps              whether record pps, enable=1, disable=0 (default disable)
    -m, --call-main             whether call main thread, enable=1, disable=0 (default enable)
    -d, --delay                 add dummy delay after touching the payload (default 1000 nanoseconds)
    -a, --app-id                application id, enable=1, disable=0 (default 0, add dummy delay)
    -b, --app-arg1              first application argument
    -c, --app-arg2              second application argument
    -h, --help                  print usage of the program
```

For EAL options, `-l` is used to specify which cores to use; `-a` is used to specify which PCIe device (i.e., NIC) to use.

When `call_main` is set to `1`, the main thread will also used to receive packets and the statistics are printed at the termination time. When `call_main` is set to `0`, the main thread will be used to print statistics periodically at a specified interval from `-i` option.

An valid example for running the receiver program on bigserver is:
```
sudo ./dpdk-rx -l 0-4 -a "0000:17:00.1" -- -d 10
```


## dpdk-tx: DPDK Sender Program

```
./dpdk-tx [EAL options] -- --options
    -p, --port                  port to send packets (default 0)
    -i, --interval              stats retrival period in second (default 1)
    -s, --size                  packet payload size
    -l, --latency               test latency size (default 0) disable it by set to 0
    -r, --packet-rate           maximum packet sending rate in packet per second (no rate limiting by default)
    -B, --source-mac            source MAC address
    -E, --dest-mac              destination MAC address
    -j, --source-ip             source IP address
    -J, --dest-ip               destination IP address
    -a, --app-diff-ip           add different dest ip for different core, enable=1, disable=0 (default disable)
    -b, --trace                 use trace, enable=1, disable=0 (default is disable)
    -h, --help                  print usage of the program
```

For EAL options, `-l` is used to specify which cores to use; `-a` is used to specify which PCIe device (i.e., NIC) to use.

An valid example for running the sender program on Wyatt-10 is:
```
sudo ./dpdk-tx -l 0-4 -a "0000:02:00.0" -- --dest-mac="08:c0:eb:31:8b:a3" --dest-ip="10.0.0.49" --source-mac="08:c0:eb:bf:ef:52" --source-ip="10.0.0.10" --size=1024
```

