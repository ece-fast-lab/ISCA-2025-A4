#! /bin/bash

#size=1500
CORE=$1
size=$2
source_port=$3
dest_mac=$4
dest_ip=$5
source_mac=$6
source_ip=$7
reduce=${8:-"0"}

sudo stdbuf -oL ./dpdk-tx -l $CORE  -a $source_port -- --dest-mac=$dest_mac --dest-ip=$dest_ip --source-mac=$source_mac --source-ip=$source_ip --size=$size -l 1000 -R $reduce -r 200000000
 #sleep 1800 
 #pkill dpdk-tx
