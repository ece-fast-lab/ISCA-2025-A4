#!/bin/bash

sudo ifconfig ens11 10.0.0.10 netmask 255.255.255.0
