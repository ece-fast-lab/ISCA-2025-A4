#!/bin/bash

sudo bash -c 'echo 8192 > /sys/devices/system/node/node0/hugepages/hugepages-2048kB/nr_hugepages'
sudo sysctl -p /etc/sysctl.conf
cat /proc/meminfo | grep -i huge

#turn off backpressure for enp2s0f1np1
sudo bash -c "echo 16 > /sys/class/infiniband/mlx5_0/tc/1/traffic_class"
sudo bash -c "echo 16 > /sys/class/infiniband/mlx5_1/tc/1/traffic_class"
sudo mlnx_qos -i ens1f1np1 --trust dscp
sudo mlnx_qos -i ens1f1np1 --dscp2prio=set,4,4
sudo mlnx_qos -i ens1f1np1 --pfc=0,0,0,0,1,0,0,0
sudo mlnx_qos -i ens1f0np0 --trust dscp
sudo mlnx_qos -i ens1f0np0 --dscp2prio=set,4,4
sudo mlnx_qos -i ens1f0np0 --pfc=0,0,0,0,1,0,0,0


