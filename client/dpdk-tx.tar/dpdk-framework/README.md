# dpdk-framework


## dpdk-rx: DPDK Receiver Program

```
./dpdk-rx [EAL options] -- [-p PORT]
    -p, --port=<PORT>           port to receive packets (default 0)
    -i, --interval=<INTERVAL>   seconds between periodic reports, only appliable when call_main is disabled (default 1)
    -l, --latency=<LATENCY>     test latency, it will store an array of latency stats (default array size is 0)
    -r, --paclet-rate=<RATE>    maximum number of packets to receive per second (no rate limiting by default)
    -t, --test-pps              whether record pps, enable=1, disable=0 (default disable)
    -m, --call-main             whether call main thread, enable=1, disable=0 (default enable)
    -d, --delay=<DUMMY DELAY>   add dummy delay after touching the payload (default 0 nanoseconds)
    -a, --app-id                application id, enable=1, disable=0 (default 0, add dummy delay)
    -b, --app-arg1              first application argument
    -c, --app-arg2              second application argument
    -h, --help                  print usage of the program
```

For EAL options, `-l` is used to specify which cores to use; `-a` is used to specify which PCIe device (i.e., NIC) to use.

When `call_main` is set to `1`, the main thread will also used to receive packets and the statistics are printed at the termination time. When `call_main` is set to `0`, the main thread will be used to print statistics periodically at a specified interval from `-i` option.

An valid example for running the receiver program on bigserver is:
```
sudo ./dpdk-rx -l 0-4 -a "0000:17:00.1" -- -d 10
```


## dpdk-tx: DPDK Sender Program

```
./dpdk-tx [EAL options] -- [-p PORT] [-i INTERVAL] [-s SIZE] [-r RATE] -B MAC -E MAC -j IP -J IP
    -p, --port=<PORT>           port to send packets (default 0)
    -i, --interval=<INTERVAL>   seconds between periodic reports (default 1)
    -s, --size=<SIZE>           packet (excluding Ethernet CRC) has <SIZE> bytes
    -l, --latency=<LATENCY>     test latency, it will store an array of latency stats (default array size is 0)
    -r, --rate=<RATE>           maximum number of packets to send per second (no rate limiting by default)
    -B, --source-mac=<MAC>      source MAC address by this format XX:XX:XX:XX:XX:XX
    -E, --dest-mac=<MAC>        destination MAC address by this format XX:XX:XX:XX:XX:XX
    -j, --source-ip=<IP>        source IP address by this format X.X.X.X
    -J, --dest-ip=<IP>          destination IP address by this format X.X.X.X
    -a, --app-diff-ip=<IP>      add different dest ip for different core, enable=1, disable=0 (default disable)
    -b, --trace=<TRACE>         use trace, enable=1, disable=0 (default is disable)
    -h, --help                  print usage of the program
```

For EAL options, `-l` is used to specify which cores to use; `-a` is used to specify which PCIe device (i.e., NIC) to use.

An valid example for running the sender program on Wyatt-10 is:
```
sudo ./dpdk-tx -l 0-4 -a "0000:02:00.0" -- --dest-mac="08:c0:eb:31:8b:a3" --dest-ip="10.0.0.49" --source-mac="08:c0:eb:bf:ef:52" --source-ip="10.0.0.10" --size=1024
```

