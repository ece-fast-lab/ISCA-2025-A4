 #! /bin/bash

#size=1500
CORE=$1
size=$2
rate=$3
dest="b8:ce:f6:d2:12:ea"
#dest="08:c0:eb:31:8b:a2"


sudo stdbuf -oL ./dpdk-tx -l $CORE -a "0000:04:00.0" -- --dest-mac=$dest --dest-ip="10.0.0.49" --source-mac="08:c0:eb:bf:ef:52" --source-ip="10.0.0.10" --size=$size -l 10000 -r $rate
#sudo stdbuf -oL ./dpdk-tx -l $CORE -a "0000:04:00.0" -- --dest-mac="08:c0:eb:31:8b:a2" --dest-ip="10.0.0.49" --source-mac="08:c0:eb:bf:ef:52" --source-ip="10.0.0.10" --size=$size -l 10000
 #sleep 1800 
 #pkill dpdk-tx
