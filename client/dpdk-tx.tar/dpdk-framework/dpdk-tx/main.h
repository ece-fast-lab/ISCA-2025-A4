#ifndef _MAIN_H_
#define _MAIN_H_


#include <stdio.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <getopt.h>
#include <unistd.h>
#include <signal.h>
#include <rte_eal.h>
#include <rte_ethdev.h>
#include <rte_timer.h>
#include <rte_random.h>
#include <math.h>

#define TX_RING_SIZE 1024
#define RX_RING_SIZE 1024
#define MTU_SIZE 1500

#define RATE_NUM 600

#define NUM_MBUFS 2047
#define MBUF_CACHE_SIZE 512
#define BURST_SIZE 64
#define MAX_TX_CORES 128

static const struct rte_eth_conf port_conf_default = {
	.txmode = {
        .mq_mode = RTE_ETH_MQ_TX_NONE
    }
};

struct my_timestamp { 
    char data[64]; 
}; 

static uint16_t port = 0;
static unsigned int interval = 1;
static uint16_t pkt_size = RTE_ETHER_MIN_LEN - RTE_ETHER_CRC_LEN;
static struct rte_ether_addr src_mac;
static struct rte_ether_addr dst_mac;
static rte_be32_t src_ip;
static rte_be32_t dst_ip;
static uint32_t pkts_per_sec = 0;
static uint32_t latency_size = 0;
static uint16_t app_diff_ip = 0;
static rte_be32_t app_dest_ip[MAX_TX_CORES];
static uint16_t trace = 0;
static double csv_rates_array[RATE_NUM];
static size_t trace_index = 0;
static size_t is_reduce = 0;

static struct rte_ether_addr my_ether_addr;

static uint64_t last_lcore_tx_pkts[MAX_TX_CORES];
static volatile uint64_t lcore_tx_pkts[MAX_TX_CORES];
// If the program is sending packets
static volatile int keep_sending = 1;

// Print usage of the program
static void print_usage(const char *prgname);
// Parse program arguments. Return 0 on success.
static int parse_args(int argc, char **argv);
// Parse argument 'port'. Return 0 on success.
static int parse_port(char *arg);
// Parse argument 'interval'. Return 0 on success.
static int parse_interval(char *arg);
// Parse argument 'latency'. Return 0 on success.
static int parse_latency(char *arg);
// Parse argument 'packet size'. Return 0 on success.
static int parse_pkt_size(char *arg);
// Parse argument 'packet rate'. Return 0 on success.
static int parse_pkt_rate(char *arg);
// Parse argument 'source MAC'. Return 0 on success.
static int parse_src_mac(char *arg);
// Parse argument 'destination MAC'. Return 0 on success.
static int parse_dst_mac(char *arg);
// Parse argument 'source IP'. Return 0 on success.
static int parse_src_ip(char *arg);
// Parse argument 'destination IP'. Return 0 on success.
static int parse_dst_ip(char *arg);
// Parse argument 'app different ip'. Return 0 on success.
static int parse_app_diff_ip(char *arg);
// Parse argument 'trace'. Return 0 on success.
static int parse_trace(char *arg);
// Parse argument 'reducerx'. Return 0 on success.
static int parse_reducerx(char *arg);
// Print MAC address
void print_mac(struct rte_ether_addr mac);
// Print IP address
void print_ip(rte_be32_t ip);
// Print the configuration of the program
static void print_config();
// Compute latency stats
int cmpfunc (const void * a, const void * b);
// Calculate poisson
double next_poisson_time(double packet_rate, uint64_t tsc_frequency);

// Initialzie a port. Return 0 on success.
//  port: ID of the port to initialize
//  mbuf_pool: packet buffer pool for RX packets
//  nb_tx_rings: number of TX rings
//  nb_rx_rings: number of RX rings
//  tx_ring_size: number of descriptors to allocate for the TX ring
//  rx_ring_size: number of descriptors to allocate for the RX ring
static int port_init(uint16_t port,
                     struct rte_mempool *mbuf_pool,
                     uint16_t nb_tx_rings,
                     uint16_t nb_rx_rings,
                     uint16_t tx_ring_size,
                     uint16_t rx_ring_size);
// Create an Ethernet header
static void create_eth_hdr(uint8_t *buf,
                           struct rte_ether_addr src_addr,
                           struct rte_ether_addr dst_addr);
// Create an UDP packet.
static void create_udp_pkt(struct rte_mbuf *pkt,
                           uint16_t pkt_len,
                           struct rte_ether_addr src_mac_addr,
                           struct rte_ether_addr dst_mac_addr,
                           rte_be32_t src_ip_addr,
                           rte_be32_t dst_ip_addr,
                           uint16_t ip_id,
                           uint16_t src_port,
                           uint16_t dst_port);

// Generate TX packets in a logical core
static int lcore_tx(void *arg);
// Handle signal and stop sending packets
static void stop_tx(int sig);


// Compute latency stats
int cmpfunc (const void * a, const void * b)
{
    if (*(double*)a > *(double*)b) return 1;
    else if (*(double*)a < *(double*)b) return -1;
    else return 0;
}

// Calculate poisson
double next_poisson_time (double packet_rate, uint64_t tsc_frequency)
{
    return -logf(1.0f - ((double)random()) / (double)(RAND_MAX)) / (packet_rate / tsc_frequency);
}

// Print usage of the program
static void print_usage(const char *prgname)
{
    printf("%s [EAL options] -- [-p PORT] [-i INTERVAL] [-s SIZE] [-r RATE] -B MAC -E MAC -j IP -J IP\n"
           "    -p, --port=<PORT>           port to send packets (default %hu)\n"
           "    -i, --interval=<INTERVAL>   seconds between periodic reports (default %u)\n"
           "    -s, --size=<SIZE>           packet (excluding Ethernet CRC) has <SIZE> bytes\n"
           "    -l, --latency=<LATENCY>     test latency, it will store an array of latency stats (default array size is %u)\n"
           "    -r, --rate=<RATE>           maximum number of packets to send per second (no rate limiting by default)\n"
           "    -B, --source-mac=<MAC>      source MAC address by this format XX:XX:XX:XX:XX:XX\n"
           "    -E, --dest-mac=<MAC>        destination MAC address by this format XX:XX:XX:XX:XX:XX\n"
           "    -j, --source-ip=<IP>        source IP address by this format X.X.X.X\n"
           "    -J, --dest-ip=<IP>          destination IP address by this format X.X.X.X\n"
           "    -a, --app-diff-ip=<IP>      add different dest ip for different core, enable=1, disable=0 (default disable)\n"
           "    -b, --trace=<TRACE>         use trace, enable=1, disable=0 (default is disable)\n"
	   "    -R, --reduced-rx=<T/F>      calculate latency for one per each burst of received packets, enable=1, disable=0 (default disable)\n"
           "    -h, --help                  print usage of the program\n",
           prgname, port, interval, latency_size);
}

// Parse program arguments. Return 0 on success.
static int parse_args(int argc, char **argv)
{
    struct option long_options[] = {
        {"port",        required_argument,  0,  'p'},
        {"interval",    required_argument,  0,  'i'},
        {"size",        required_argument,  0,  's'},
        {"latency",     required_argument,  0,  'l'},
        {"rate",        required_argument,  0,  'r'},
        {"source-mac",  required_argument,  0,  'B'},
        {"dest-mac",    required_argument,  0,  'E' },
        {"source-ip",   required_argument,  0,  'j' },
        {"dest-ip",     required_argument,  0,  'J' },
        {"app-diff-ip", required_argument,  0,  'a' },
        {"trace",       required_argument,  0,  'b' },
	{"reduced-rx" , required_argument,  0,  'R' },
        {"help",        no_argument,        0,  'h'},
        {0,             0,                  0,  0 }
    };
    char short_options[] = "p:i:s:l:r:B:E:j:J:a:b:R:h";
    char *prgname = argv[0];
    int nb_required_args = 0;
    int ret;

    while (1) {
        int c = getopt_long(argc, argv, short_options, long_options, NULL);

        if (c == -1) {
            break;
        }

        switch (c) {
            case 'p':
                ret = parse_port(optarg);
                if (ret < 0) {
                    return -1;
                }
                break;

            case 'i':
                ret = parse_interval(optarg);
                if (ret < 0) {
                    return -1;
                }
                break;

            case 's':
                ret = parse_pkt_size(optarg);
                if (ret < 0) {
                    return -1;
                }
                break;

            case 'l':
                ret = parse_latency(optarg);
                if (ret < 0) {
                    return -1;
                }
                break;

            case 'r':
                ret = parse_pkt_rate(optarg);
                if (ret < 0) {
                    return -1;
                }
                break;

            case 'B':
                ret = parse_src_mac(optarg);
                if (ret < 0) {
                    return -1;
                }
                nb_required_args++;
                break;

            case 'E':
                ret = parse_dst_mac(optarg);
                if (ret < 0) {
                    return -1;
                }
                nb_required_args++;
                break;

            case 'j':
                ret = parse_src_ip(optarg);
                if (ret < 0) {
                    return -1;
                }
                nb_required_args++;
                break;

            case 'J':
                ret = parse_dst_ip(optarg);
                if (ret < 0) {
                    return -1;
                }
                nb_required_args++;
                break;

            case 'a':
                ret = parse_app_diff_ip(optarg);
                if (ret < 0) {
                    return -1;
                }
                break;

            case 'b':
                ret = parse_trace(optarg);
                if (ret < 0) {
                    return -1;
                }
                break;
	    
	    case 'R':
		ret = parse_reducerx(optarg);
		if (ret < 0) {
		    return -1;
		}
		break;

            case 'h':
            default:
                print_usage(prgname);
                return -1;
        }
    }

    if (nb_required_args != 4) {
        fprintf(stderr, "We need <source_mac>, <dest_mac>, <source_ip>, <dest_ip>\n");
        print_usage(prgname);
        return -1;
    }

    if (optind >= 0) {
        argv[optind-1] = prgname;
    }

    // reset getopt lib
    optind = 1;

    return 0;
}

// Parse argument 'port'. Return 0 on success.
static int parse_port(char *arg)
{
    long n;
    char **endptr;

    n = strtol(arg, endptr, 10);
    if (n < 0) {
        fprintf(stderr, "PORT should be a non-negative integer argument\n");
        return -1;
    }

    port = (uint16_t)n;
    uint16_t nb_ports = rte_eth_dev_count_avail();
    if (port >= nb_ports) {
        fprintf(stderr, "PORT should be smaller than %hu (total # of available ports)\n", nb_ports);
        return -1;
    }

    return 0;
}

// Parse argument 'interval'. Return 0 on success.
static int parse_interval(char *arg)
{
    unsigned int n;
    char **endptr;

    n = strtoul(arg, endptr, 10);
    if (n == 0) {
        fprintf(stderr, "INTERVAL should be a positive integer argument\n");
        return -1;
    }

    interval = n;
    return 0;
}

// Parse argument 'packet size'. Return 0 on success.
static int parse_pkt_size(char *arg)
{
    uint16_t n;
    char **endptr;

    n = (uint16_t)strtoul(arg, endptr, 10);
    if (n == 0) {
        fprintf(stderr, "PKT_SIZE should be a positive integer argument\n");
        return -1;
    }

    uint16_t min_pkt_size = RTE_ETHER_MIN_LEN - RTE_ETHER_CRC_LEN;
    uint16_t max_pkt_size = RTE_ETHER_MAX_LEN - RTE_ETHER_CRC_LEN;
    if (n < min_pkt_size || n > max_pkt_size) {
        fprintf(stderr, "PKT_SIZE should be in [%hu, %hu]\n", min_pkt_size, max_pkt_size);
        return -1;
    }

    pkt_size = n;
    return 0;
}

// Parse argument 'latency'. Return 0 on success.
static int parse_latency(char *arg)
{
    uint32_t n;
    char **endptr;

    n = (uint32_t)strtoul(arg, endptr, 10);
    latency_size = n;

    return 0;
}

// Parse argument 'packet rate'. Return 0 on success.
static int parse_pkt_rate(char *arg)
{
    uint32_t n;
    char **endptr;

    n = (uint32_t)strtoul(arg, endptr, 10);
    if (n == 0) {
        fprintf(stderr, "PKT_RATE should be a positive integer argument\n");
        return -1;
    }

    pkts_per_sec = n;
    return 0;
}

// Parse argument 'source MAC'. Return 0 on success.
static int parse_src_mac(char *arg)
{
    if (rte_ether_unformat_addr(arg, &src_mac) < 0) {
        fprintf(stderr, "Invalid SRC_MAC %s\n", arg);
        return -1;
    }

    return 0;
}

// Parse argument 'destination MAC'. Return 0 on success.
static int parse_dst_mac(char *arg)
{
    if (rte_ether_unformat_addr(arg, &dst_mac) < 0) {
        fprintf(stderr, "Invalid DST_MAC %s\n", arg);
        return -1;
    }

    return 0;
}

// Parse argument 'source IP'. Return 0 on success.
static int parse_src_ip(char *arg)
{
    if (inet_pton(AF_INET, arg, &src_ip) <= 0) {
        fprintf(stderr, "Invalid SRC_IP %s\n", arg);
        return -1;
    }

    return 0;
}

// Parse argument 'destination IP'. Return 0 on success.
static int parse_dst_ip(char *arg)
{
    if (inet_pton(AF_INET, arg, &dst_ip) <= 0) {
        fprintf(stderr, "Invalid DST_IP %s\n", arg);
        return -1;
    }

    return 0;
}

// Parse argument 'app different ip'. Return 0 on success.
static int parse_app_diff_ip(char *arg)
{
    uint32_t n;
    char **endptr;

    n = (uint32_t)strtoul(arg, endptr, 10);
    app_diff_ip = n;

    return 0;
}

// Parse argument 'trace'. Return 0 on success.
static int parse_trace(char *arg)
{
    uint32_t n;
    char **endptr;

    n = (uint32_t)strtoul(arg, endptr, 10);
    trace = n;

    return 0;
}

// Parse argument 'reducerx'. Return 0 on success.
static int parse_reducerx(char *arg)
{
    uint32_t n;
    char **endptr;
    
    n = (uint32_t)strtoul(arg, endptr, 10);
    if(n == 0 || n == 1){
	is_reduce = n;
	return 0;
    }else{
	return -1;
    }
}

// Print MAC address
void print_mac(struct rte_ether_addr mac)
{
	printf("%02" PRIx8 ":%02" PRIx8 ":%02" PRIx8
	       ":%02" PRIx8 ":%02" PRIx8 ":%02" PRIx8 "\n",
           mac.addr_bytes[0], mac.addr_bytes[1], mac.addr_bytes[2],
           mac.addr_bytes[3], mac.addr_bytes[4], mac.addr_bytes[5]);
}

// Print IP address
void print_ip(rte_be32_t ip)
{
    struct in_addr addr = {.s_addr = ip};
    printf("%s\n", inet_ntoa(addr));
}

// Print the configuration of the program
static void print_config()
{
    printf("===================== Configuration =====================\n");
    printf("Port:           %u\n", port);
    printf("Interval:       %u sec\n", interval);
    printf("Packet Size:    %u bytes\n", pkt_size);
    printf("Packet Rate:    ");
    if (pkts_per_sec == 0) {
        printf("N/A (no rate limiting)\n");
    } else {
        printf("%u\n", pkts_per_sec);
    }
    printf("Src MAC:        ");
    print_mac(src_mac);
    printf("Dst MAC:        ");
    print_mac(dst_mac);
    printf("Src IP:         ");
    print_ip(src_ip);
    printf("Dst IP:         ");
    print_ip(dst_ip);
    printf("=========================================================\n");
}

// Initialzie a port. Return 0 on success.
//  port: ID of the port to initialize
//  mbuf_pool: packet buffer pool for RX packets
//  nb_tx_rings: number of TX rings
//  nb_rx_rings: number of RX rings
//  tx_ring_size: number of transmission descriptors to allocate for the TX ring
//  rx_ring_size: number of transmission descriptors to allocate for the RX ring
static int port_init(uint16_t port,
                     struct rte_mempool *mbuf_pool,
                     uint16_t nb_tx_rings,
                     uint16_t nb_rx_rings,
                     uint16_t tx_ring_size,
                     uint16_t rx_ring_size)
{
    struct rte_eth_conf port_conf = port_conf_default;
    uint16_t nb_txd = tx_ring_size;
    uint16_t nb_rxd = rx_ring_size;
    int retval;
    struct rte_eth_dev_info dev_info;

    printf("Init port %hu\n", port);

    if (!rte_eth_dev_is_valid_port(port)) {
		return -1;
    }

    // Get device information
    retval = rte_eth_dev_info_get(port, &dev_info);
    if (retval != 0) {
        fprintf(stderr, "Error during getting device (port %u) info: %s\n", port, strerror(-retval));
        return retval;
    }
    // printf("PCI address: %s\n", dev_info.device->name);

    // Configure RSS
    port_conf.rx_adv_conf.rss_conf.rss_hf &= dev_info.flow_type_rss_offloads;
    if (port_conf.rx_adv_conf.rss_conf.rss_hf !=
        port_conf_default.rx_adv_conf.rss_conf.rss_hf) {
            printf("Port %u modifies RSS hash function based on hardware support,"
                   "requested:%#"PRIx64" configured:%#"PRIx64"\n",
                   port,
                   port_conf_default.rx_adv_conf.rss_conf.rss_hf,
                   port_conf.rx_adv_conf.rss_conf.rss_hf);
    }

    // Configure the Ethernet device
    retval = rte_eth_dev_configure(port, nb_rx_rings, nb_tx_rings, &port_conf);
    if (retval != 0) {
        fprintf(stderr, "Error during rte_eth_dev_configure\n");
        return retval;
    }

    // Adjust # of descriptors for each TX/RX ring
    retval = rte_eth_dev_adjust_nb_rx_tx_desc(port, &nb_rxd, &nb_txd);
    if (retval != 0) {
        fprintf(stderr, "Error during rte_eth_dev_adjust_nb_rx_tx_desc\n");
        return retval;
    }

    int socket_id = rte_eth_dev_socket_id(port);
    //printf("Socket ID = %d\n", socket_id);

    // TX setup
    for (uint16_t q = 0; q < nb_tx_rings; q++) {
        retval = rte_eth_tx_queue_setup(port, q, nb_txd, socket_id, NULL);
        if (retval < 0) {
            fprintf(stderr, "Error during rte_eth_tx_queue_setup for queue %hu\n", q);
			return retval;
        }
    }
    printf("Set up %hu TX rings (%hu descriptors per ring)\n", nb_tx_rings, nb_txd);

    // RX setup
    for (uint16_t q = 0; q < nb_rx_rings; q++) {
        retval = rte_eth_rx_queue_setup(port, q, nb_rxd, socket_id, NULL, mbuf_pool);
        if (retval < 0) {
            fprintf(stderr, "Error during rte_eth_rx_queue_setup for queue %hu\n", q);
            return retval;
        }
    }
    printf("Set up %hu RX rings (%hu descriptors per ring)\n", nb_rx_rings, nb_rxd);

    // Start the Ethernet port.
    retval = rte_eth_dev_start(port);
    if (retval < 0) {
        fprintf(stderr, "Error during rte_eth_dev_start\n");
        return retval;
    }

    // Display the port MAC address
    struct rte_ether_addr addr;
    retval = rte_eth_macaddr_get(port, &addr);
    if (retval != 0) {
        fprintf(stderr, "Error during rte_eth_macaddr_get\n");
        return retval;
    }
    printf("Port %hu MAC: ", port);
    print_mac(addr);

    my_ether_addr = addr;

	// Enable RX in promiscuous mode for the Ethernet device.
    retval = rte_eth_promiscuous_enable(port);
    if (retval != 0) {
        fprintf(stderr, "Error during rte_eth_promiscuous_enable\n");
        return retval;
    }

	return 0;
}

// Create an UDP packet.
static void create_udp_pkt(struct rte_mbuf *pkt,
                           uint16_t pkt_len,
                           struct rte_ether_addr src_mac_addr,
                           struct rte_ether_addr dst_mac_addr,
                           rte_be32_t src_ip_addr,
                           rte_be32_t dst_ip_addr,
                           uint16_t ip_id,
                           uint16_t src_port,
                           uint16_t dst_port)
{
    uint16_t ip_pkt_len = pkt_len - sizeof(struct rte_ether_hdr);
    uint16_t udp_pkt_len = ip_pkt_len - sizeof(struct rte_ipv4_hdr);

    struct rte_ether_hdr *eth_hdr = rte_pktmbuf_mtod(pkt, struct rte_ether_hdr*);
    size_t offset = sizeof(struct rte_ether_hdr);
    struct rte_ipv4_hdr *ip_hdr = rte_pktmbuf_mtod_offset(pkt,
                                                          struct rte_ipv4_hdr*,
                                                          offset);
    offset = sizeof(struct rte_ether_hdr) + sizeof(struct rte_ipv4_hdr);
    struct rte_udp_hdr *udp_hdr = rte_pktmbuf_mtod_offset(pkt,
                                                          struct rte_udp_hdr*,
                                                          offset);

    eth_hdr->src_addr = src_mac_addr;
    eth_hdr->dst_addr = dst_mac_addr;
    eth_hdr->ether_type = rte_cpu_to_be_16(RTE_ETHER_TYPE_IPV4);

    ip_hdr->src_addr = src_ip_addr;
    ip_hdr->dst_addr = dst_ip_addr;
    ip_hdr->version_ihl = RTE_IPV4_VHL_DEF;
    ip_hdr->type_of_service = 2;
    ip_hdr->total_length = rte_cpu_to_be_16(ip_pkt_len);
    ip_hdr->packet_id = rte_cpu_to_be_16(ip_id);
    ip_hdr->fragment_offset = 0;
    ip_hdr->time_to_live = 64;
    ip_hdr->next_proto_id = IPPROTO_UDP;
    ip_hdr->hdr_checksum = 0;
    ip_hdr->hdr_checksum = rte_ipv4_cksum(ip_hdr);

    udp_hdr->src_port = rte_cpu_to_be_16(src_port);
    udp_hdr->dst_port = rte_cpu_to_be_16(dst_port);
    udp_hdr->dgram_len = rte_cpu_to_be_16(udp_pkt_len);
    udp_hdr->dgram_cksum = 0;
    udp_hdr->dgram_cksum = rte_ipv4_udptcp_cksum(ip_hdr, udp_hdr);

    pkt->data_len = pkt_len;
    pkt->pkt_len = pkt->data_len;
}

// Handle signal and stop sending packets
static void stop_tx(int sig)
{
    keep_sending = 0;
}


#endif /* _MAIN_H_ */
