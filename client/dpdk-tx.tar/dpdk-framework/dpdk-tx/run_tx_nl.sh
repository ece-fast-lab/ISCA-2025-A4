 #! /bin/bash

#size=1500
CORE=$1
size=$2

 ./dpdk-tx -l $CORE -a "0000:02:00.0" -- --dest-mac="08:c0:eb:31:8b:a3" --dest-ip="10.0.0.49" --source-mac="08:c0:eb:bf:ef:52" --source-ip="10.0.0.10" --size=$size & 
 #sleep 1800 
 #pkill dpdk-tx
