#! /bin/bash

#size=1500
CORE=$1
size=$2
reduce=${3:-"0"}

sudo stdbuf -oL ./dpdk-tx -l $CORE  -a "0000:a8:00.1" -- --dest-mac="b8:ce:f6:d2:12:ea" --dest-ip="192.168.200.32" --source-mac="08:c0:eb:bf:ef:53" --source-ip="192.168.200.11" --size=$size -l 1000 -R $reduce -r 200000000
 #sleep 1800 
 #pkill dpdk-tx
