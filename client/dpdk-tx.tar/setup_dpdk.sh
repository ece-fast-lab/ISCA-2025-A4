#!/usr/bin/env bash

echo 8192 | sudo tee /sys/kernel/mm/hugepages/hugepages-2048kB/nr_hugepages
sudo sysctl -p /etc/sysctl.conf
cat /proc/meminfo | grep -i huge


# unload NIC
#sudo ifconfig ens11 down

# bind NIC
#eth_controller=$(lspci -D | grep XL710)
#echo "Current NIC plugged: $eth_controller"

#pat='[0-9]+\:[0-9]+\:[0-9]+\.[0-9]'
#[[ $eth_controller =~ $pat ]]
#pci_addr=${BASH_REMATCH[0]}
#echo "NIC PCIe to be bind: $pci_addr"

#sudo dpdk-devbind.py --bind=vfio-pci $pci_addr
#sudo dpdk-devbind.py -s
